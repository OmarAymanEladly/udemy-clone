function Navbar() {
return ( <nav className="navbar">
     <h2>Udemy</h2> 
     <input type="text" placeholder="Search for anything" /> 
     </nav>
);
}

export default Navbar;
