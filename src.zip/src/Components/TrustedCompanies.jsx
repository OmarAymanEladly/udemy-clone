function TrustedCompanies() {
const companies = ["Volkswagen", "Nvidia", "Samsung", "Coca-Cola"];

return ( <div className="trusted"> 
<h2>Trusted by companies around the world</h2> 
<div className="logos">
{companies.map((company, index) => ( <span key={index}>{company}</span>
))} </div> </div>
);
}

export default TrustedCompanies;
