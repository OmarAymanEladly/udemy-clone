function Banner() {
return ( <div className="banner">
     <h1>Learning that gets you</h1>
      <p>Skills for your present and your future.</p> 
      </div>
);
}

export default Banner;
