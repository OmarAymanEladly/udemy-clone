import { courses } from "../data/Courses";

function CourseList() {
return ( <div className="course-list">
{courses.map((course, index) => ( <div key={index} className="course-card"> <img src={course.image} alt={course.title} /> <h3>{course.title}</h3> <p>{course.instructor}</p> <strong>${course.price}</strong> </div>
))} </div>
);
}

export default CourseList;
