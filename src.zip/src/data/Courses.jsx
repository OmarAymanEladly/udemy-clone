export const courses = [
{
title: "React - The Complete Guide",
instructor: "Maximilian",
rating: 4.7,
price: 19.99,
image: "[https://via.placeholder.com/200](https://via.placeholder.com/200)"
},
{
title: "Python Bootcamp",
instructor: "Jose Portilla",
rating: 4.8,
price: 14.99,
image: "[https://via.placeholder.com/200](https://via.placeholder.com/200)"
}
];
