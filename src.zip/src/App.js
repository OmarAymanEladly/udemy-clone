import Navbar from "./Components/Navbar";
import Banner from "./Components/Banner";
import CourseList from "./Components/CourseList";
import TrustedCompanies from "./Components/TrustedCompanies";

function App() {
return (
<> <Navbar /> <Banner /> <CourseList /> <TrustedCompanies />
</>
);
}

export default App;
